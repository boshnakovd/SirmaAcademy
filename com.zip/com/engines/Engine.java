package com.engines;

public interface Engine {
    void start();
}
