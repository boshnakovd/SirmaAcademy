package com.engines;

public class combustionEngine implements Engine{
    @Override
    public void start(){
        System.out.println("Combustion engine start");
    }
}
