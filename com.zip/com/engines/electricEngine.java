package com.engines;

public class electricEngine implements Engine{
    @Override
    public void start(){
        System.out.println("engine kaput");
    }
}
