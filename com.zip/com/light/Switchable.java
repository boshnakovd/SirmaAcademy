package com.light;

public interface Switchable {
    void turnOn();
    void turnOff();

}
