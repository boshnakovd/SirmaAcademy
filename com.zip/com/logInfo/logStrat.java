package com.logInfo;

public interface logStrat {
    void log(String message);
}