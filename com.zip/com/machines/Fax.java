package com.machines;

public interface Fax {
    void fax();
}
