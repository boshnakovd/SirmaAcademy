package com.machines;

public interface Machine {
    void print();
    void scan();
    void fax();
}
