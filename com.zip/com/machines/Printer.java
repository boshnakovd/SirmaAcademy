package com.machines;

public interface Printer {
    void print();

}
