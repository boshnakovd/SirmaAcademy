package com.machines;

public interface Scanner {
    void scan();
}
