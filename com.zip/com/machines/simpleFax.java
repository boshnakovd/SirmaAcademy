package com.machines;

public class simpleFax implements Fax{
    @Override
    public void fax(){
        System.out.println("Faxing...");
    }
}
