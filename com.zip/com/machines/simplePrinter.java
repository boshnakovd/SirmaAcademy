package com.machines;

public class simplePrinter implements Printer{
    @Override
    public void print(){
        System.out.println("Printing...");
    }
}
