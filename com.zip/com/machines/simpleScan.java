package com.machines;

public class simpleScan implements Scanner{
    @Override
    public void scan(){
        System.out.println("Scanning...");
    }
}
